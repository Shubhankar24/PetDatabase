﻿using System.ComponentModel.DataAnnotations;

namespace PetManagementSystem.Models
{
    public class Pet
    {
        [Key]
        public int PetId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Type { get; set; }

        [Required(ErrorMessage ="DOB is Required !")]
        [DataType(DataType.Date)]
        public DateOnly DOB { get; set; }

        [Required]
        public string OwnerName { get; set; }

        [Required]
        [EmailAddress(ErrorMessage ="Email Id is Manadatory !")]
        public string OwnerEmail { get; set; }





    }
}
