﻿using Microsoft.AspNetCore.Mvc;
using PetManagementSystem.Models;

namespace PetManagementSystem.Controllers
{
    public class PetController : Controller
    {
        PetDbContext context;
        public PetController(PetDbContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            List<Pet> pets = context.Pets.ToList();
            return View(pets);
        }

        [HttpGet]

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Pet p)
        {
            if (ModelState.IsValid)
            {
                context.Pets.Add(p);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(p);

        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Pet pet = context.Pets.Find(id);
            return View(pet);
        }

        [HttpPost]
        public IActionResult Edit(Pet p)
        {
            Pet pet = context.Pets.Find(p.PetId);
            pet.Name = p.Name;
            pet.Type = p.Type;
            pet.DOB = p.DOB;
            pet.OwnerName = p.OwnerName;
            pet.OwnerEmail = p.OwnerEmail;
            context.Pets.Update(pet);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            Pet pet = context.Pets.Find(id);
            return View(pet);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Pet pet = context.Pets.Find(id);
            return View(pet);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            Pet pet = context.Pets.Find(id);
            context.Pets.Remove(pet);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
